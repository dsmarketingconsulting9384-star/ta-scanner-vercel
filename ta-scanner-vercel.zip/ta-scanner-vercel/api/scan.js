// Vercel Serverless Function: Keepa + Amazon PA API
// Set env vars in Vercel project: KEEPA_KEY, PA_ACCESS_KEY, PA_SECRET_KEY, PA_PARTNER_TAG
const crypto = require('crypto');

const PA_HOST = process.env.PA_HOST || 'webservices.amazon.com';
const PA_REGION = process.env.PA_REGION || 'us-east-1';
const SERVICE = 'ProductAdvertisingAPI';
const ENDPOINT = `https://${PA_HOST}/paapi5/searchitems`;

const round2 = (n)=> Math.round(n*100)/100;
function computeProfit({ retailerPrice, amazonPrice, referralPct = 0.15, fbaFee = 3.5 }){
  const referralFee = amazonPrice * referralPct;
  const amazonFees = referralFee + fbaFee;
  const netRevenue = amazonPrice - amazonFees;
  const profit = netRevenue - retailerPrice;
  const marginPct = (profit / retailerPrice) * 100;
  return { profit: round2(profit), marginPct: round2(marginPct) };
}
function parseTitleFromHtml(html){
  const m = html.match(/<title>([^<]+)<\/title>/i);
  return m ? m[1].trim() : 'Unknown Product';
}
function parseLikelyPrice(html){
  const m = html.match(/\$\s*([0-9]+\.?[0-9]*)/);
  if (!m) return null;
  const n = parseFloat(m[1]);
  return isNaN(n) ? null : n;
}

// PA API SigV4 helpers
function hash(payload){ return crypto.createHash('sha256').update(payload, 'utf8').digest('hex'); }
function hmac(key, data){ return crypto.createHmac('sha256', key).update(data, 'utf8').digest(); }
function toHex(bytes){ return Buffer.from(bytes).toString('hex'); }
function amzDate(date){
  const pad = (n)=> (n<10? '0'+n : ''+n);
  const YYYY = date.getUTCFullYear();
  const MM = pad(date.getUTCMonth()+1);
  const DD = pad(date.getUTCDate());
  const HH = pad(date.getUTCHours());
  const mm = pad(date.getUTCMinutes());
  const ss = pad(date.getUTCSeconds());
  return { short: `${YYYY}${MM}${DD}`, long: `${YYYY}${MM}${DD}T${HH}${mm}${ss}Z` };
}

async function paapiSearch({ keywords }){
  const accessKey = process.env.PA_ACCESS_KEY;
  const secretKey = process.env.PA_SECRET_KEY;
  const partnerTag = process.env.PA_PARTNER_TAG;
  if (!accessKey || !secretKey || !partnerTag){
    throw new Error('Missing PA API env vars (PA_ACCESS_KEY, PA_SECRET_KEY, PA_PARTNER_TAG)');
  }

  const body = {
    Keywords: keywords,
    SearchIndex: "All",
    ItemCount: 1,
    Resources: [
      "Images.Primary.Small",
      "ItemInfo.Title",
      "Offers.Listings.Price",
      "BrowseNodeInfo.WebsiteSalesRank"
    ],
    PartnerTag: partnerTag,
    PartnerType: "Associates"
  };
  const payload = JSON.stringify(body);
  const method = 'POST';
  const service = SERVICE;
  const host = PA_HOST;
  const region = PA_REGION;
  const canonicalUri = '/paapi5/searchitems';
  const canonicalQuerystring = '';
  const contentType = 'application/json; charset=UTF-8';
  const headers = {
    'content-encoding': 'amz-1.0',
    'content-type': contentType,
    'host': host,
    'x-amz-target': 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems'
  };

  const now = new Date();
  const { short: dateStamp, long: amzLong } = amzDate(now);
  headers['x-amz-date'] = amzLong;

  const signedHeaders = Object.keys(headers).sort().join(';');
  const canonicalHeaders = Object.keys(headers).sort().map(k => k.toLowerCase() + ':' + headers[k]).join('\n') + '\n';
  const payloadHash = hash(payload);
  const canonicalRequest = [method, canonicalUri, canonicalQuerystring, canonicalHeaders, signedHeaders, payloadHash].join('\n');

  const algorithm = 'AWS4-HMAC-SHA256';
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const stringToSign = [algorithm, amzLong, credentialScope, hash(canonicalRequest)].join('\n');

  const kDate = hmac('AWS4' + secretKey, dateStamp);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  const kSigning = hmac(kService, 'aws4_request');
  const signature = toHex(hmac(kSigning, stringToSign));

  const authorization = `${algorithm} Credential=${accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

  const res = await fetch(ENDPOINT, {
    method,
    headers: {
      ...headers,
      'Authorization': authorization,
      'x-amz-content-sha256': payloadHash,
      'x-amz-date': amzLong
    },
    body: payload
  });

  if (!res.ok){
    const t = await res.text();
    throw new Error('PA API error: ' + res.status + ' ' + t);
  }
  const data = await res.json();
  if (!data.ItemsResult || !data.ItemsResult.Items || data.ItemsResult.Items.length === 0){
    return null;
  }
  const item = data.ItemsResult.Items[0];
  const asin = item.ASIN;
  const title = item.ItemInfo?.Title?.DisplayValue || item.DetailPageURL || 'Amazon Item';
  const price = item.Offers?.Listings?.[0]?.Price?.Amount || null;
  const websiteRank = item.BrowseNodeInfo?.WebsiteSalesRank?.SalesRank || null;
  return { asin, title, priceFromPA: price, websiteRankFromPA: websiteRank };
}

// Keepa
async function keepaGet({ asin }){
  const key = process.env.KEEPA_KEY;
  if (!key) throw new Error('Missing KEEPA_KEY env var');
  const url = `https://api.keepa.com/product?key=${encodeURIComponent(key)}&domain=1&asin=${encodeURIComponent(asin)}&stats=1`;
  const r = await fetch(url);
  if (!r.ok){
    const t = await r.text();
    throw new Error('Keepa error: ' + r.status + ' ' + t);
  }
  const j = await r.json();
  const p = j?.products?.[0];
  if (!p) return null;
  let rank = null;
  if (p?.stats && typeof p.stats.currentSalesRank === 'number'){
    rank = p.stats.currentSalesRank;
  } else if (p?.salesRanks) {
    const vals = Object.values(p.salesRanks);
    if (vals.length && Array.isArray(vals[0]) && vals[0].length){
      const v = vals[0];
      rank = typeof v[v.length-1] === 'number' ? v[v.length-1] : null;
    }
  }
  let buyBox = null;
  if (p?.buyBoxPrice && p.buyBoxPrice.length){
    buyBox = p.buyBoxPrice[p.buyBoxPrice.length-1] / 100.0;
  } else if (p?.stats?.buyBoxPrice) {
    buyBox = p.stats.buyBoxPrice / 100.0;
  }
  return { rank, buyBox, keepaTitle: p.title };
}

module.exports = async (req, res) => {
  if (req.method === 'GET') {
    return res.status(200).json({ ok:true, msg:'scan function alive (POST to use it)' });
  }
  try {
    const { items = [], minMarginPct = 30, maxAmazonRank = 100000 } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Provide items' });
    }

    const results = [];
    for (const it of items.slice(0, 5)) {
      try {
        const page = await fetch(it.url, { headers: { 'user-agent': 'Mozilla/5.0' } });
        const html = await page.text();
        const retailTitle = parseTitleFromHtml(html);
        const retailerPriceFallback = parseLikelyPrice(html);
        const retail = { title: retailTitle, price: retailerPriceFallback, source: it.retailer || 'unknown' };

        const pa = await paapiSearch({ keywords: retailTitle });
        if (!pa || !pa.asin) continue;

        const k = await keepaGet({ asin: pa.asin });
        if (!k || !k.rank) continue;

        const amazonPrice = (pa.priceFromPA || k.buyBox || null);
        if (!amazonPrice || !retail.price) continue;

        const { profit, marginPct } = computeProfit({ retailerPrice: retail.price, amazonPrice });
        const candidate = {
          retailer: it.retailer || 'unknown',
          url: it.url,
          retail,
          amazon: { asin: pa.asin, title: pa.title || k.keepaTitle || retailTitle, price: round2(amazonPrice), rank: k.rank, priceSource: pa.priceFromPA ? 'PA' : (k.buyBox ? 'Keepa' : 'unknown') },
          profit, marginPct
        };
        if (k.rank <= maxAmazonRank && marginPct >= minMarginPct) results.push(candidate);
      } catch (e) {
        // swallow item errors
      }
    }
    return res.status(200).json({ results });
  } catch (e) {
    return res.status(500).json({ error: String(e) });
  }
};
