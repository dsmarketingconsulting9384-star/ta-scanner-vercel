# Tactical Arbitrage — Vercel (Keepa + Amazon PA API)

This project deploys on **Vercel** with:
- Static frontend in `/public`
- Serverless function **/api/scan** using **Keepa + Amazon PA API**

## Deploy (no build step)

1. Create a new Vercel project → **Import** this folder (or upload as a zip).
2. In **Project → Settings → Environment Variables**, add:
   - `KEEPA_KEY`
   - `PA_ACCESS_KEY`
   - `PA_SECRET_KEY`
   - `PA_PARTNER_TAG`
   - *(optional)* `PA_HOST=webservices.amazon.com`, `PA_REGION=us-east-1`
3. Visit your site:
   - `/` shows the UI.
   - `/api/scan` (GET) returns a health JSON.
   - The UI posts to `/api/scan`.

## Local test
```bash
npm i -g vercel
vercel dev
# open http://localhost:3000
```

Notes:
- Quotas apply for PA API and Keepa.
- Retailer price parsing is a heuristic fallback.
- Improve FBA fee model for category-specific accuracy.
